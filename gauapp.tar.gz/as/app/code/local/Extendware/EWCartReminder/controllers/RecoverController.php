<?php

class Extendware_EWCartReminder_RecoverController extends Extendware_EWCore_Controller_Frontend_Action
{

	public function cartAction()
	{
		$id = (int) $this->getInput('id');
		$recoveryCode = (string) $this->getInput('code');
		
		$params = array('reminder_id' => $id, 'recovery_code' => $recoveryCode);
		$history = Mage::getModel('ewcartreminder/history')->loadByData($params);
		
		if (!$history->getId() || $history->getRecoveryCode() != $recoveryCode) {
			return $this->_redirect('/');
		}
		
		$this->processVisit($history);
		$this->redirectToCart($history);
	}

	public function unsubscribeAction()
	{
		$id = (int) $this->getInput('id');
		$recoveryCode = (string) $this->getInput('code');
		
		$params = array('reminder_id' => $id, 'recovery_code' => $recoveryCode);
		$history = Mage::getModel('ewcartreminder/history')->loadByData($params);
		
		if (!$history->getId() || $history->getRecoveryCode() != $recoveryCode) {
			return $this->_redirect('/');
		}
		
		$model = Mage::getModel('ewcartreminder/blacklist')->loadByEmail($history->getCustomerEmail());
		if (!$model->getId()) {
			$model->setEmailAddress($history->getCustomerEmail());
			$model->save();
		}
		
		Mage::getResourceModel('ewcartreminder/reminder')->deleteByCustomerEmail($history->getCustomerEmail());
		
		if (Extendware::helper('ewpagecache')) {
    		Mage::helper('ewpagecache')->setReasonNotDefaultRequest('reminder', true);
    		Mage::helper('ewpagecache')->sendIsNotDefaultRequestCookie();
    	}
    	
		$this->_getSession()->addSuccess($this->__('You will no longer receive any more cart reminder e-mails'));
		return $this->_redirect('/');
	}
	protected function updateHistory($history)
	{
		if ($history and $history->getId() > 0) {
			if (is_empty_date($history->getRecoveredAt())) {
				$history->setRecoveredAt(now());
			}
			if (!$history->getRecoveredFrom()) {
				if (isset($_SERVER['REMOTE_ADDR'])) {
					$history->setRecoveredFrom($_SERVER['REMOTE_ADDR']);
				}
			}
			
			$history->save();
		}
	}
	
	protected function processVisit($history)
	{
		$this->updateHistory($history);
		if (Mage::getStoreConfig('ewcartreminder/general/stop_after_visit')) {
			// delete all reminders with this email address
			$model = Mage::getResourceModel('ewcartreminder/reminder');
			$model->deleteByCustomerEmail($history->getCustomerEmail());
			
			// delete all reminders with this customer id
			if ($history->getCustomerId() > 0) {
				$model = Mage::getResourceModel('ewcartreminder/reminder');
				$model->deleteByCustomerId($history->getCustomerId());
			}
		}
	}
	
	protected function redirectToCart($history)
	{
		$queryParams = $_GET;
		$trackingParams = array();

		$reminder = Mage::getModel('ewcartreminder/reminder');
		$reminder->setReminderNum($history->getReminderNum());
		$reminder->setStoreId($history->getStoreId());
		@parse_str($reminder->getReminderConfigData('email/tracking_params'), $trackingParams);
		if (empty($trackingParams) === false) {
			$queryParams = array_merge($queryParams, $trackingParams);
		}

		$s = Mage::getSingleton('customer/session');
		if ($s->isLoggedIn()) {
			if ($history->getCustomerId() == $s->getCustomerId()) {
				return @$this->_redirect(Mage::getStoreConfig('ewcartreminder/advanced/redirect_route'), array('_query' => $queryParams));
			} else $s->logout();
		}

		// log customer in
		if ($history->getCustomerId()) {
			$customer = Mage::getModel('customer/customer')->load($history->getCustomerId());
			if ($customer->getId()) $s->setCustomerAsLoggedIn($customer);
		} elseif ($history->getQuoteId()) {
			// just a visitor, restore quote
			$quote = Mage::getModel('sales/quote')->load($history->getQuoteId());
			if ($quote) {
				Mage::getSingleton('checkout/session')->replaceQuote($quote);
			}
		}

		
		return @$this->_redirect(Mage::getStoreConfig('ewcartreminder/advanced/redirect_route'), array('_query' => $queryParams));
	}
}

