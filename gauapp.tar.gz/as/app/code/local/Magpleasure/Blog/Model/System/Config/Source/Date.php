<?php
 /**
  * MagPleasure Ltd.
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the EULA
  * that is bundled with this package in the file LICENSE-EE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://www.magpleasure.com/LICENSE-EE.txt
  *
  * =================================================================
  *                 MAGENTO EDITION USAGE NOTICE
  * =================================================================
  * This package designed for Magento ENTERPRISE edition
  * MagPleasure does not guarantee correct work of this extension
  * on any other Magento edition except Magento ENTERPRISE edition.
  * Magpleasure does not provide extension support in case of
  * incorrect edition usage.
  * =================================================================
  *
  * @category   MagPleasure
  * @package    Magpleasure_Blog
  * @version    2.0.4
  * @copyright  Copyright (c) 2012-2015 MagPleasure Ltd. (http://www.magpleasure.com)
  * @license    http://www.magpleasure.com/LICENSE-EE.txt
  */

class Magpleasure_Blog_Model_System_Config_Source_Date
    extends Magpleasure_Common_Model_System_Config_Source_Abstract
{
    /**
     * Blog Helper
     *
     * @return Magpleasure_Blog_Helper_Data
     */
    protected function _helper()
    {
        return Mage::helper('mpblog');
    }

    public function toArray()
    {
        $date = new Zend_Date();
        $date->subDay(6)->subHour(5)->subHour(3);

        return array(
            Magpleasure_Blog_Helper_Date::DATE_TIME_PASSED => $this->_helper()->_date()->getHumanizedDate($date),
            Magpleasure_Blog_Helper_Date::DATE_TIME_DIRECT => $this->_helper()->_date()->renderDate($date, null, true),
        );
    }
}

