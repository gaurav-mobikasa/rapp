<?php
 /**
  * MagPleasure Ltd.
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the EULA
  * that is bundled with this package in the file LICENSE-EE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://www.magpleasure.com/LICENSE-EE.txt
  *
  * =================================================================
  *                 MAGENTO EDITION USAGE NOTICE
  * =================================================================
  * This package designed for Magento ENTERPRISE edition
  * MagPleasure does not guarantee correct work of this extension
  * on any other Magento edition except Magento ENTERPRISE edition.
  * Magpleasure does not provide extension support in case of
  * incorrect edition usage.
  * =================================================================
  *
  * @category   MagPleasure
  * @package    Magpleasure_Blog
  * @version    2.0.4
  * @copyright  Copyright (c) 2012-2015 MagPleasure Ltd. (http://www.magpleasure.com)
  * @license    http://www.magpleasure.com/LICENSE-EE.txt
  */

$installer = $this;
$installer->startSetup();

$installer->run("

CREATE TABLE IF NOT EXISTS `{$this->getTable('mp_blog_drafts')}`(
  `draft_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `post_id` INT(10) UNSIGNED,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  `full_content` TEXT NOT NULL,
  `short_content` TEXT,
  PRIMARY KEY (`draft_id`),
  INDEX (`user_id`, `post_id`),
  CONSTRAINT `FK_MPBLOG_DRAFT_TO_POST` FOREIGN KEY (`post_id`) REFERENCES `{$this->getTable('mp_blog_posts')}`(`post_id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8;

");


$installer->endSetup();