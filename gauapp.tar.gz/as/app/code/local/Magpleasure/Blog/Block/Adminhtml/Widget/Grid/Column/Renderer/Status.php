<?php
 /**
  * MagPleasure Ltd.
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the EULA
  * that is bundled with this package in the file LICENSE-EE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://www.magpleasure.com/LICENSE-EE.txt
  *
  * =================================================================
  *                 MAGENTO EDITION USAGE NOTICE
  * =================================================================
  * This package designed for Magento ENTERPRISE edition
  * MagPleasure does not guarantee correct work of this extension
  * on any other Magento edition except Magento ENTERPRISE edition.
  * Magpleasure does not provide extension support in case of
  * incorrect edition usage.
  * =================================================================
  *
  * @category   MagPleasure
  * @package    Magpleasure_Blog
  * @version    2.0.4
  * @copyright  Copyright (c) 2012-2015 MagPleasure Ltd. (http://www.magpleasure.com)
  * @license    http://www.magpleasure.com/LICENSE-EE.txt
  */


class Magpleasure_Blog_Block_Adminhtml_Widget_Grid_Column_Renderer_Status
    extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Options
{
    /**
     * Helper
     * @return Magpleasure_Blog_Helper_Data
     */
    protected function _helper()
    {
        return Mage::helper('mpblog');
    }

    /**
     * Date Helper
     *
     * @return Magpleasure_Blog_Helper_Date
     */
    protected function _date()
    {
        return Mage::helper('mpblog/date');
        
    }
    
    /**
     * Renders grid column
     *
     * @param   Varien_Object $row
     * @return  string
     */
    public function render(Varien_Object $row)
    {
        $status = $row->getStatus();
        $scheduledAt = $row->getPublishedAt();
        $localeCode = Mage::app()->getLocale()->getLocaleCode();

        if (($status == Magpleasure_Blog_Model_Post::STATUS_SCHEDULED) && $scheduledAt){

            $scheduledAt = new Zend_Date(
                $scheduledAt,
                Varien_Date::DATETIME_INTERNAL_FORMAT,
                $localeCode
            );
            $scheduledAt
                ->setTimezone(
                    $this->_date()->getTimezone()
                );

            $label = $this->_helper()->__(
                    "Scheduled on %s",
                    $scheduledAt->toString(Zend_Date::DATETIME_MEDIUM
                )
            );

            return $label;

        } else {
            return parent::render($row);
        }
    }
}