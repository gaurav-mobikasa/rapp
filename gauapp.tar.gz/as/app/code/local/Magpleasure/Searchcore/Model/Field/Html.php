<?php
 /**
  * MagPleasure Ltd.
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the EULA
  * that is bundled with this package in the file LICENSE-EE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://www.magpleasure.com/LICENSE-EE.txt
  *
  * =================================================================
  *                 MAGENTO EDITION USAGE NOTICE
  * =================================================================
  * This package designed for Magento ENTERPRISE edition
  * MagPleasure does not guarantee correct work of this extension
  * on any other Magento edition except Magento ENTERPRISE edition.
  * Magpleasure does not provide extension support in case of
  * incorrect edition usage.
  * =================================================================
  *
  * @category   MagPleasure
  * @package    Magpleasure_Searchcore
  * @version    1.0.10
  * @copyright  Copyright (c) 2013-2015 MagPleasure Ltd. (http://www.magpleasure.com)
  * @license    http://www.magpleasure.com/LICENSE-EE.txt
  */

class Magpleasure_Searchcore_Model_Field_Html extends Magpleasure_Searchcore_Model_Field_Default
{

}