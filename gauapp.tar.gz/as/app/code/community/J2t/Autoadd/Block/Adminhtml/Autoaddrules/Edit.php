<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@j2t-design.com so we can send you a copy immediately.
 *
 * @category   Magento extension
 * @package    J2T_Autoadd
 * @copyright  Copyright (c) 2009 J2T DESIGN. (http://www.j2t-design.net)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class J2t_Autoadd_Block_Adminhtml_Autoaddrules_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
	$this->_objectId = 'id';
        $this->_blockGroup = 'autoadd';
        $this->_controller = 'adminhtml_autoaddrules';


        //Rewardpoints_Model_Pointrules::RULE_ACTION_TYPE_ADD

        $this->_formScripts[] = "
            

            
            document.observe('dom:loaded', function() {
                $('lnk_trigger').observe('click', function (event){
                    showProductGrid();
                    productGridJsObject.setPage('1');                    
                });
                $('lnk_trigger_zone').observe('click', function (event){
                    showProductzoneGrid();
                    productzoneGridJsObject.setPage('1');                    
                });
            });
            
            

            function hideProductGridzone(){
                $('rule_add_productzone_grid').previous(0).style.display = 'none';
                $('rule_add_productzone_grid').style.display = 'none';
                $('rule_productzone').style.display = 'none';

                if (!$('lnk_select_productzone')){
                    var newElement = document.createElement('a');
                    newElement.setAttribute('id', 'lnk_select_productzone');
                    newElement.setAttribute('href', 'javascript:showProductzoneGrid(); void(0)');
                    newElement.appendChild(document.createTextNode($('rule_productzone').value + '...'));
                    $('rule_productzone').up().insert({'top':newElement});
                }

                $('lnk_select_productzone').innerText = $('rule_productzone').value + '...';
                $('lnk_select_productzone').style.display = 'inline';

                $('lnk_applyzone').style.display = 'none';

            }


            function hideProductGrid(){
                $('rule_add_product_grid').previous(0).style.display = 'none';
                $('rule_add_product_grid').style.display = 'none';
                $('rule_result').style.display = 'none';

                if (!$('lnk_select_product')){
                    var newElement = document.createElement('a');
                    newElement.setAttribute('id', 'lnk_select_product');
                    newElement.setAttribute('href', 'javascript:showProductGrid(); void(0)');
                    newElement.appendChild(document.createTextNode($('rule_result').value + '...'));
                    $('rule_result').up().insert({'top':newElement});
                }

                $('lnk_select_product').innerText = $('rule_result').value + '...';
                $('lnk_select_product').style.display = 'inline';

                $('lnk_apply').style.display = 'none';

            }

            function showProductGrid(){
                $('rule_add_product_grid').previous(0).style.display = 'block';
                $('rule_add_product_grid').style.display = 'inline';
                if ($('lnk_select_product')){
                    $('lnk_select_product').style.display = 'none';
                    $('rule_result').style.display = 'inline';
                }
                $('lnk_apply').style.display = 'inline';
                $('rule_add_product_grid').scrollTo();
            }
            
            function showProductzoneGrid(){
                $('rule_add_productzone_grid').previous(0).style.display = 'block';
                $('rule_add_productzone_grid').style.display = 'inline';
                if ($('lnk_select_productzone')){
                    $('lnk_select_productzone').style.display = 'none';
                    $('rule_productzone').style.display = 'inline';
                }
                $('lnk_applyzone').style.display = 'inline';
                $('rule_add_productzone_grid').scrollTo();
            }


            document.observe('dom:loaded', function() {
                hideProductGrid();
                hideProductGridzone();
            });

            function saveAndContinueEdit(){ editForm.submit($('edit_form').action + 'back/edit/') }

        ";


        parent::__construct();

        $this->_updateButton('save', 'label', Mage::helper('autoadd')->__('Save Rule'));
        $this->_updateButton('delete', 'label', Mage::helper('autoadd')->__('Delete Rule'));
        
        $this->_addButton('save_and_continue', array(
            'label'     => Mage::helper('salesrule')->__('Save and Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class' => 'save'
        ), 10);

        $filter = Mage::registry('autoaddrules_data');
    }

    public function getHeaderText()
    {
        $rule = Mage::registry('autoaddrules_data');
        if ($rule->getRuleId()) {
            return Mage::helper('autoadd')->__("Edit Rule '%s'", $this->htmlEscape($rule->getTitle()));
        }
        else {
            return Mage::helper('autoadd')->__('New Rule');
        }
    }
}
