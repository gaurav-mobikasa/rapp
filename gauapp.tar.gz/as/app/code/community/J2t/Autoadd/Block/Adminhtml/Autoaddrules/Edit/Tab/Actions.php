<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@j2t-design.com so we can send you a copy immediately.
 *
 * @category   Magento extension
 * @package    J2T_Autoadd
 * @copyright  Copyright (c) 2009 J2T DESIGN. (http://www.j2t-design.net)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class J2t_Autoadd_Block_Adminhtml_Autoaddrules_Edit_Tab_Actions extends Mage_Adminhtml_Block_Widget_Form
{

    protected function _prepareForm()
    {
        $model = Mage::registry('autoaddrules_data');

        $form = new Varien_Data_Form();
        $form->setHtmlIdPrefix('rule_');

        $fieldset = $form->addFieldset('action_fieldset', array('legend'=>Mage::helper('autoadd')->__('Actions')));

        /*

        $fieldset->addField('action_type', 'select', array(
            'label'     => Mage::helper('autoadd')->__('Type of action'),
            'name'      => 'action_type',
            'values'    => $model->ruleActionTypesToOptionArray(),
            'after_element_html' => '',
            'required'  => true,
        ));
*/

        $fieldset->addField('action_type', 'select', array(
            'label'     => Mage::helper('autoadd')->__('Type of action'),
            'name'      => 'action_type',
            'values'    => $model->ruleActionTypesToOptionArray(),
            'after_element_html' => '',
            'required'  => true,
            'note'   => Mage::helper('autoadd')->__('If you decide to show the list of product in the shopping cart, only one product will be added.').
            Mage::helper('autoadd')->__('When allowing customer to remove auto added product(s) from cart, note that auto add rule will not take any further actions.'),
        ));



        $fieldset->addField('coupon_add', 'text', array(
            'title'     => Mage::helper('autoadd')->__('Coupon code'),
            'label'     => Mage::helper('autoadd')->__('Coupon code'),
            'required'  => false,
            'name'      => 'coupon_add',
            'note'   => Mage::helper('autoadd')->__('Optionnal. This coupon code would be added to your cart if the rule is met.'),
        ));

        $script_add = array();
        if ($model->getData('result')){
            $arr_result = explode(',', $model->getData('result'));
            foreach($arr_result as $res){
                $script_add[] = 'autoadd_product.chooserSelectedItems.set("'.trim($res).'",1);';
            }
        }

        $js_element = '<script type="text/javascript">
            var autoadd_product = function() {
                return {
                    productInfoUrl : null,
                    formHidden : true,
                    chooserSelectedItems : $H({}),
                    updateElement : null,
                    
                    
                    gridRowClickOld : function(data, click) {
                        if(Event.findElement(click,\'TR\').title){
                            autoadd_product.productInfoUrl = Event.findElement(click,\'TR\').title;
                        }
                    },
                    
                    gridRowClick : function (grid, event) {
                        var trElement = Event.findElement(event, \'tr\');
                        var isInput = Event.element(event).tagName == \'INPUT\';
                        if (trElement) {
                            var checkbox = Element.select(trElement, \'input\');
                            if (checkbox[0]) {
                                var checked = isInput ? checkbox[0].checked : !checkbox[0].checked;
                                grid.setCheckboxChecked(checkbox[0], checked);
                            }
                        }
                    },

                    chooserGridCheckboxCheck: function (grid, element, checked) {
                        if (checked) {
                            if (!element.up(\'th\')) {
                                autoadd_product.chooserSelectedItems.set(element.value,1);
                            }
                        } else {
                            autoadd_product.chooserSelectedItems.unset(element.value);
                        }
                        $(\'rule_result\').value = autoadd_product.chooserSelectedItems.keys().join(\', \');
                        grid.reloadParams = {\'selected[]\':autoadd_product.chooserSelectedItems.keys()};
                        autoadd_product.updateElement.value = autoadd_product.chooserSelectedItems.keys().join(\', \');

                    },

                    chooserGridRowInit: function (grid, row) { 
                        if (!grid.reloadParams) {
                            grid.reloadParams = {\'selected[]\':autoadd_product.chooserSelectedItems.keys()};
                        }
                    },

                    loadProductData : function() {
                        var con = new Ext.lib.Ajax.request(\'POST\', autoadd_product.productInfoUrl, {success:autoadd_product.reqSuccess,failure:autoadd_product.reqFailure}, {form_key:FORM_KEY});
                    },

                    showForm : function() {
                        toggleParentVis("add_autoadd_product_form");
                        toggleVis("productGrid");
                        toggleVis("save_button");
                        toggleVis("reset_button");
                    },

                    updateRating: function() {
                        elements = [$("select_stores"), $("rating_detail").getElementsBySelector("input[type=\'radio\']")].flatten();
                        $(\'save_button\').disabled = true;
                        var params = Form.serializeElements(elements);
                        if (!params.isAjax) {
                            params.isAjax = "true";
                        }
                        if (!params.form_key) {
                            params.form_key = FORM_KEY;
                        }
                        new Ajax.Updater("rating_detail", "'.$this->getUrl('*/*/ratingItems').'", {parameters:params, evalScripts: true,  onComplete:function(){ $(\'save_button\').disabled = false; } });
                    },

                    reqSuccess :function(o) {
                        var response = Ext.util.JSON.decode(o.responseText);
                        if( response.error ) {
                            alert(response.message);
                        } else if( response.id ){
                            $("product_id").value = response.id;
                            $("product_name").innerHTML = \'<a href="' . $this->getUrl('*/catalog_product/edit') . 'id/\' + response.id + \'" target="_blank">\' + response.name + \'</a>\';
                        } else if( response.message ) {
                            alert(response.message);
                        }
                    }
                }
            }();
            document.observe(\'dom:loaded\', function() {
                '.implode(' ', $script_add).'
                productGridJsObject.reloadParams = {\'selected[]\':autoadd_product.chooserSelectedItems.keys()};
            });
            
            </script>';

        $gridFieldset = $form->addFieldset('add_product_grid', array('legend' => Mage::helper('review')->__('Please select a product')));
        //Mage_Adminhtml_Block_Catalog_Product_Edit_Tab_Crosssell
        $gridFieldset->addField('products_grid', 'note', array(
            /*'text' => $this->getLayout()->createBlock('adminhtml/review_product_grid')->toHtml(),*/

            'text' => $js_element.$this->getLayout()->createBlock('autoadd/adminhtml_gridproduct')->toHtml(),
        ));


        $image_trigger = Mage::getDesign()->getSkinUrl('images/rule_chooser_trigger.gif');
        $image_apply = Mage::getDesign()->getSkinUrl('images/rule_component_apply.gif');

        $fieldset->addField('isfree', 'select', array(
            'label'     => Mage::helper('autoadd')->__('Free product label'),
            'title'     => Mage::helper('autoadd')->__('Free product label'),
            'name'      => 'isfree',
            'options'    => array(
                '1' => Mage::helper('autoadd')->__('Yes'),
                '0' => Mage::helper('autoadd')->__('No'),
            ),
            'note'   => Mage::helper('autoadd')->__('Show the added products as FREE on shopping cart (need custom modification. See documentation).'),
        ));
        
        $fieldset->addField('match_quantity', 'select', array(
            'label'     => Mage::helper('autoadd')->__('Match product quantity'),
            'title'     => Mage::helper('autoadd')->__('Match product quantity'),
            'name'      => 'match_quantity',
            'options'    => array(
                '1' => Mage::helper('autoadd')->__('Yes'),
                '0' => Mage::helper('autoadd')->__('No'),
            ),
            'note'   => Mage::helper('autoadd')->__('Match product quantity (quantity will be the addition of product(s) concerned by the rule). Only works with "Product Subselection" and the auto added product must be different form the product checked in the rule.'),
        ));
        

        $fieldset->addField('result', 'text', array(
            'title'     => Mage::helper('autoadd')->__('Products to be added'),
            'label'     => Mage::helper('autoadd')->__('Products to be added'),
            'class'     => 'required-entry',
            'required'  => true,
            'name'      => 'result',
            'after_element_html' => '<a id="lnk_trigger" href="#"><img class="v-middle" src="'.$image_trigger.'" alt="" /></a><a id="lnk_apply" href="javascript:hideProductGrid();"><img class="v-middle" src="'.$image_apply.'" alt="" /></a>',
            'note'   => Mage::helper('autoadd')->__('Use simple products without mandatory custom fields.'),
        ));
        
        //javascript:showProductGrid();


        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
