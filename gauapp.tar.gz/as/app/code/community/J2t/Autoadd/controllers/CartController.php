<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@j2t-design.com so we can send you a copy immediately.
 *
 * @category   Magento extension
 * @package    J2T_Autoadd
 * @copyright  Copyright (c) 2009 J2T DESIGN. (http://www.j2t-design.net)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

require_once 'Mage/Checkout/controllers/CartController.php';

class J2t_Autoadd_CartController extends Mage_Checkout_CartController {

    public function old_couponPostAction()
    {
        $couponCode = "";
        if ($this->getRequest()->getParam('remove') != 1) {
            $couponCode = (string) $this->getRequest()->getParam('coupon_code');
            
            $this->_getQuote()->setAutoaddCouponTest(strlen($couponCode) ? $couponCode : '')
                ->save();
            
            //echo $this->_getQuote()->getAutoaddCouponTest();
            //die;
            //Mage::getModel('autoadd/observer')->processCoupon($couponCode);
            //Mage::helper('autoadd/data')->processCoupon($couponCode);
            
            Mage::helper('autoadd/data')->processCouponPost($couponCode);
        } else {
            $this->_getQuote()->setAutoaddCouponTest(strlen($couponCode) ? $couponCode : '')
                ->save();
        }
        
        
        
        parent::couponPostAction();
    }
}
