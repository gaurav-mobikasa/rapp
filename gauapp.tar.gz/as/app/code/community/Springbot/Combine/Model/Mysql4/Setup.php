<?php

class Springbot_Combine_Model_Mysql4_Setup extends Springbot_Combine_Model_Resource_Setup
{
}
